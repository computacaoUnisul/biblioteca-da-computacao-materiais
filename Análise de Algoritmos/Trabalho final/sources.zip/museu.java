package TrabalhoFinal;

public class museu {

    public static void main(String[] args) {
        new Main();

//        new ExemploTrabalho();
    }

}
