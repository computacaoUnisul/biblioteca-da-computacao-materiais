import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class AStart {

	public static void main(String[] args) {
		int larg = 30;
		int alt = 30;
		Nodo[][] tabela = new Nodo[larg][alt];
		
		//inicializa a tabela
		for (int i=0; i<alt; i++) {
			for (int j=0; j<larg; j++) {
				tabela[i][j] = new Nodo(i,j);
			}
		}
		
		//constroi as barreiras
		//y=5 ; x=5..20
		for (int i=5; i<21; i++) {
			tabela[5][i].passavel = false;
		}
		//y=5..20 ; x=20
		for (int i=5; i<21; i++) {
			tabela[i][20].passavel = false;
		}
		//y=20 ; x=5..20
		for (int i=0; i<5; i++) {
			tabela[20][i].passavel = false;
		}
		for (int i=7; i<21; i++) {
			tabela[20][i].passavel = false;
		}
		//tabela[20][18].passavel = true;
		mostraTabela(tabela, larg, alt);
		
		Nodo inicial  = tabela[12][3]; //nodo (4,13)
		Nodo objetivo = tabela[21][21]; //nodo (22,22)
		inicial.custoG = 0;
		inicial.custoH = calculaH(inicial, objetivo);
		inicial.custoF = inicial.custoG + inicial.custoH;
		
		Nodo raizCaminho = calculaAStar(tabela, larg, alt, inicial, objetivo);
		if (raizCaminho == null) {
			System.out.println("Caminho n�o encontrado!");
		} else {
			System.out.println("Caminho encontrado:");
			Nodo atual = raizCaminho;
			while (atual != null) {
				tabela[atual.y][atual.x].caminho = true;
				System.out.println(atual);
				atual = atual.pai;
			}
		}
		mostraTabela(tabela, larg, alt);
	}

	private static int calculaH(Nodo nodo1, Nodo nodo2) {
		int custoX = Math.abs(nodo1.x - nodo2.x);
		int custoY = Math.abs(nodo1.y - nodo2.y);
		return custoX + custoY;
	}

	public static Nodo calculaAStar(Nodo[][] tabela, int larg, int alt, Nodo inicial, Nodo objetivo) {
		HashSet<Nodo> listaAberta = new HashSet<Nodo>();
		HashSet<Nodo> listaFechada = new HashSet<Nodo>();
		listaAberta.add(inicial);
		boolean encontrado = false;
		Nodo atual = null;
		while (!encontrado) {
			atual = getMenorCustoF(listaAberta.iterator());
			if (atual == null) { //caminho n�o encontrado!
				return null;
			}
			listaFechada.add(atual);
			listaAberta.remove(atual);
			if (atual.equals(objetivo)) {
				encontrado = true;
				continue;
			}
			ArrayList<Nodo> listaAdjacentes = getAdjacentes(tabela, larg, alt, atual);
			for (Nodo nodo : listaAdjacentes) {
				if ((!nodo.passavel) || (listaFechada.contains(nodo))) {
					//ignora
				} else {
					if (!listaAberta.contains(nodo)) {//n�o est� na lista aberta
						listaAberta.add(nodo);
						nodo.pai = atual;
						nodo.custoG = nodo.pai.custoG+1;
						nodo.custoH = calculaH(nodo, objetivo);
						nodo.custoF = nodo.custoG + nodo.custoH;
					} else {//j� est� na lista aberta
						if (atual.custoG < nodo.pai.custoG) {
							nodo.pai = atual;
							nodo.custoG = nodo.pai.custoG+1;
							nodo.custoH = calculaH(nodo, objetivo);
							nodo.custoF = nodo.custoG + nodo.custoH;
						}
					}
				}
			}
		}
		return atual;
	}

	private static ArrayList<Nodo> getAdjacentes(Nodo[][] tabela, int larg, int alt, Nodo atual) {
		ArrayList<Nodo> listaAdjacentes = new ArrayList<Nodo>(4);
		//pega o nodo da esquerda
		if (atual.x > 0) {
			Nodo esq = tabela[atual.y][atual.x-1];
			listaAdjacentes.add(esq);
		}
		//pega o nodo da direita
		if (atual.x < larg-1) {
			Nodo dir = tabela[atual.y][atual.x+1];
			listaAdjacentes.add(dir);
		}
		//pega o nodo de cima
		if (atual.y > 0) {
			Nodo cima = tabela[atual.y-1][atual.x];
			listaAdjacentes.add(cima);
		}
		//pega o nodo de baixo
		if (atual.y < alt-1) {
			Nodo baixo = tabela[atual.y+1][atual.x];
			listaAdjacentes.add(baixo);
		}
		return listaAdjacentes;
	}

	private static Nodo getMenorCustoF(Iterator<Nodo> it) {
		Nodo menorCusto = null;
		while (it.hasNext()) {
			Nodo n = it.next();
			if (menorCusto == null) {
				menorCusto = n;
			} else {
				if (n.custoF < menorCusto.custoF) {
					menorCusto = n;
				}
			}
		}
		return menorCusto;
	}

	private static void mostraTabela(Nodo[][] tabela, int larg, int alt) {
		for (int j=0; j<alt; j++) {
			for (int i=0; i<larg; i++) {
				if (tabela[j][i].caminho) {
					System.out.print(".");
				} else if (tabela[j][i].passavel) {
					System.out.print(" ");
				} else {
					System.out.print("X");
				}
			}
			System.out.println();
		}
	}
}
