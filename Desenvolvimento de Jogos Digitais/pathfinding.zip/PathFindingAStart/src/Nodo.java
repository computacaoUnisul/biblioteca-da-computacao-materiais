
public class Nodo {

	public int x = 0;
	public int y = 0;
	public Nodo pai = null;
	public int custoG = Integer.MAX_VALUE;
	public int custoH = Integer.MAX_VALUE;
	public int custoF = Integer.MAX_VALUE;
	public boolean passavel = true;
	public boolean caminho = false;
	
	
	public Nodo(int y, int x) {
		this.x = x;
		this.y = y;
	}
	
	public String toString() {
		return "["+y+","+x+"]";
	}
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Nodo)) {
			return false;
		}
		Nodo objComp = (Nodo)obj;
		if ((objComp.x == this.x) && (objComp.y == this.y)) {
			return true;
		}
		return false;
	}
}
