package trabalho_3;

public class Vertice {
	
	private int nomeVertice;

	
	public int getNomeVertice() {
		return nomeVertice;
	}

	public void setNomeVertice(int nomeVertice) {
		this.nomeVertice = nomeVertice;
	}

}
