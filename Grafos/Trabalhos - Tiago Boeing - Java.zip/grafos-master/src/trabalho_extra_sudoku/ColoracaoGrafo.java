package trabalho_extra_sudoku;

public interface ColoracaoGrafo {
	
	//	define o grafo g
    public void colorir(Grafo g);
    
}
