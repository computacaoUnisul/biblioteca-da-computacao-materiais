package trabalho_extra_sudoku.copy;

public interface ColoracaoGrafo {
	
	//	define o grafo g
    public void colorir(Grafo g);
    
}
