# Programação Orientada a Objetos
POG - Programação Orientada a Gambiarra<br>
<br>
<p>Linguagem: Java</p>
<p>Semestre: 2016/2</p>

- UNISUL - UNIVERSIDADE DO SUL DE SANTA CATARINA<br>
- Professor: Clávison Martinelli Zapelini<br>
- Curso: Ciência da Computação

<b><i>Alguns pacotes podem conter erros, por se tratar de atividades é necessário repará-los.</i></b>

<h4>Nome do pacote java: poo</h4>


<h2>MODO DE USAR:</h2>
Crie um projeto com qualquer nome, clone o repositório dentro da pasta <b>src/</b> do projeto.

<h3>Netbeans</h3>
Vá no menu Novo projeto > atribua qualquer nome ao projeto (no meu caso poo).<br>
Guarde o local no disco onde seu projeto foi criado, por padrão o caminho é: <br>
<b>Documentos\NetBeansProjects\poo</b><br>
<i>*Neste caso, <b>poo</b> é o nome do projeto que criei.</i><br>
<br><br>
Navegue para a pasta <b>src/</b> do projeto e clone o repositório dentro dela. Será criada uma subpasta chamada poo/ que conterá todos os arquivos organizados por mais subpastas e seus scripts.<br>
*No eclipse o procedimento é semelhante, mudando apenas o diretório do projeto.
