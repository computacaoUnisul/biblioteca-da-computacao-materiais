/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.Sistema7Setembro;

/**
 *
 * @author Tiago Boeing
 */
public class Adulto extends Ala{

    public Adulto(String nomeAla, String tipoAla) {
        super("Nome da ala: " + nomeAla, "Tipo de ala: ADULTO");
    }
    
    
    
}
