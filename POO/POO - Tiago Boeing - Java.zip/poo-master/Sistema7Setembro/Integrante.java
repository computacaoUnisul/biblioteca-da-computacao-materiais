/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.Sistema7Setembro;

/**
 *
 * @author Tiago Boeing
 */
public class Integrante {
    
    private String nomeIntegrante;
    private Integer idadeIntegrante;

    public String getNomeIntegrante() {
        return nomeIntegrante;
    }

    public void setNomeIntegrante(String nomeIntegrante) {
        this.nomeIntegrante = nomeIntegrante;
    }

    public Integer getIdadeIntegrante() {
        return idadeIntegrante;
    }

    public void setIdadeIntegrante(Integer idadeIntegrante) {
        this.idadeIntegrante = idadeIntegrante;
    }
    
}
