package poo.atividade1;

/**
 *
 * @author Tiago Boeing
 */
public class Vendedor {
    
}
