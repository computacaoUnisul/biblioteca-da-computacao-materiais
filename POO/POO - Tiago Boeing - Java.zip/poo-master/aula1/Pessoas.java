//Cadastrar pessoas e informar o IMC e o nome das pessoas cadastradas

package poo.aula1;

public class Pessoas {
	String nome;
	double peso, altura;

}
