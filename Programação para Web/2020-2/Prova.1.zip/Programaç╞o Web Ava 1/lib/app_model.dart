import 'package:flutter_web_aula/pages/default_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_web_aula/domain/pagina.dart';

class AppModel extends ChangeNotifier {
  List<Pagina> pages = [];

  AppModel() {
    pages.add(Pagina("Home", PaginaDefault()));
  }

  setPage(Pagina page, {bool replace = false}) {
    if(replace){
      pages.clear();
      pages.add(Pagina("Home", PaginaDefault()));
    }
    if(page.titulo != "Home")
      pages.add(page);
    notifyListeners();
  }
  removePage(){
    pages.removeLast();
    notifyListeners();
  }

  void desempilhaTodas(){
    pages.clear();
    pages.add(Pagina("Home", PaginaDefault()));
    notifyListeners();
  }

  void desempilhaAte(int index){
    pages.removeRange(index+1, pages.length);
    notifyListeners();
  }
}