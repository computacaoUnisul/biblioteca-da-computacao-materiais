import 'package:flutter/material.dart';
import 'package:flutter_web_aula/app_model.dart';
import 'package:flutter_web_aula/pages/carros/carro.dart';
import 'package:provider/provider.dart';

class DetalheCarroPage extends StatefulWidget{
  Carro c;
  DetalheCarroPage(this.c);

  @override
  _DetalheCarroPageState createState() => _DetalheCarroPageState();
  }

  class _DetalheCarroPageState extends State<DetalheCarroPage>{

  @override
  Widget build(BuildContext context){
  return _body();
  }

  _body(){
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Image.network(
            widget.c.urlFoto??"http://www.livroandroid.com.br/livro/carros/esportivos/Renaut_Megane_Trophy.png"
          ),
          Text(
            widget.c.nome ?? " ",
            overflow: TextOverflow.ellipsis,
          ),
          Text(
            widget.c.descricao ?? " ",
            overflow: TextOverflow.ellipsis,
          ),
          RaisedButton(
            child: Text("Voltar"),
            onPressed: _onClickVoltar,
          )
        ],
      ),
    );
  }

  void _onClickVoltar(){
    AppModel app = Provider.of<AppModel>(context, listen: false);
    app.removePage();
  }
}