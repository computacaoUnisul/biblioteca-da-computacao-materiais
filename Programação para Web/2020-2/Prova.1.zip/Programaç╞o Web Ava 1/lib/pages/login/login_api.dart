import 'package:flutter_web_aula/domain/usuario.dart';
import 'package:flutter_web_aula/utils/api_response.dart';
import 'dart:convert' as convert;
import 'package:http/http.dart' as http;

class LoginApi{
  static Future<ApiResponse<Usuario>> login(String login, String senha) async {
    try{
      var url = 'https://carros-springboot.herokuapp.com/api/v2/login';

      Map<String, String> headers = {"Content-Type":"application/json"};

      String body = convert.json.encode({
        "username": login,
        "password": senha,
      });
      //print(">> $body");

      var response = await http.post(url, body: body, headers: headers);

      //print('status: ${response.statusCode}');
      //print('body: ${response.body}');

      Map mapResponse = convert.json.decode(response.body);

      if(response.statusCode == 200){
        final user = Usuario.fromMap(mapResponse);

        return ApiResponse.ok(resultado: user);
      }
      return ApiResponse.error(msg: mapResponse["error"]);
    }catch(error, exception){
      //print("Erro no login $error > $exception");

      return ApiResponse.error(msg: "Não foi possível fazer o login.");
    }
  }
}