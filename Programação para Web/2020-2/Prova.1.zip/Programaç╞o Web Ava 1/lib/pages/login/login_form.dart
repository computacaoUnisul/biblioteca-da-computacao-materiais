import 'package:flutter/material.dart';
import 'package:flutter_web_aula/domain/usuario.dart';
import 'package:flutter_web_aula/home.dart';
import 'package:flutter_web_aula/pages/carros/carros_page.dart';
import 'package:flutter_web_aula/pages/login/login_api.dart';
import 'package:flutter_web_aula/utils/alert.dart';
import 'package:flutter_web_aula/utils/api_response.dart';
import 'package:flutter_web_aula/utils/nav.dart';

class LoginForm extends StatefulWidget{
  @override
  _LoginFormState createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm>{

  final _formKey = GlobalKey<FormState>();
  final _txtLogin = TextEditingController();
  final _txtSenha = TextEditingController();

  String _validaLogin(String txt){
    if(txt.toString().isEmpty){
      return "Digite o login";
    }
    return null;
  }

  String _validaSenha(String txt){
    if(txt.toString().isEmpty){
      return "Digite a senha";
    }
    if(txt.toString().length<3){
      return "A senha precisa ter pelo menos 3 números";
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: <Widget>[
          _campoDeTexto("Login", "Digite o login", controller: _txtLogin, validacao: _validaLogin),
          Divider(),
          _campoDeTexto("Senha", "Digite a senha", obscure: true, controller: _txtSenha, validacao: _validaSenha),
          Divider(),
          _botao(),
        ],
      ),
    );
  }

  _botao(){
    return Container(
      height: 50,
      width: 250,

      child: RaisedButton(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        onPressed: _onClickLogin,
        color: Color.fromARGB(255, 252, 0, 0),
        child: Text(
          "Login",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
          ),
        ),
      ),
    );
  }
  _campoDeTexto(String label, String hint, {bool obscure = false, controller, validacao }){
    return TextFormField(
      controller: controller,
      validator: validacao,
      keyboardType: TextInputType.text,
      obscureText: obscure,
      style: TextStyle(color: Colors.black),
      decoration: InputDecoration(
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
          labelText: label,
          labelStyle: TextStyle(fontSize: 16.0, color: Colors.black),
          hintText: hint
      ),
    );
  }

  void _onClickLogin() async{
    if(!_formKey.currentState.validate()){
      return;
    }
    String login = _txtLogin.text;
    String senha = _txtSenha.text;
    //print("Login: ${_txtLogin.text}, Senha: ${_txtSenha.text}");

    ApiResponse<Usuario> response = await LoginApi.login(login, senha);

    if(response.ok){
      Usuario user = response.resultado;
      usuario = user;
      /*print("User API $user");*/
      if(user.isAdmin()){
        push(context, HomePage(), replace: true);
      }else{
        push(context, CarrosPage(), replace: true);
      }
    }else{
      alert(context, response.msg, "Login");
    }
  }
}