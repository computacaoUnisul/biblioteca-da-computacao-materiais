class ApiResponse<T>{
  bool ok;
  String msg;
  T resultado;

  ApiResponse.ok({this.resultado, this.msg}){
   ok = true;
  }
  ApiResponse.error({this.resultado, this.msg}){
    ok = false;
  }
}