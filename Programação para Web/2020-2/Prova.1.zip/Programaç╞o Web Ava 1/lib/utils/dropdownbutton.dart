import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'DropDownButton - DropDownItem',
      home: DropDown(),
    );
  }
}

class DropDown extends StatefulWidget {
  @override
  _DropDownState createState() => _DropDownState();
}

class _DropDownState extends State<DropDown> {
   
   String tipoCarro="";
   var _tipos =['Luxo','Esportivo','Clássico',''];
   var _itemSelecionado = '';

   @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("DropDownButton"),
        backgroundColor: Colors.red,
       ),
       body: criaDropDownButton(),
   );
  }

   criaDropDownButton() {
     return Container(
       child: Column(
         children: <Widget>[
           Text("Selecione o tipo de carro"),
           TextField(
             onSubmitted: (String userInput) {
               setState(() {
                debugPrint('chamei setState');
                tipoCarro = userInput;
               });
             },
           ),
           DropdownButton<String>(
             items : _tipos.map((String dropDownStringItem) {
               return DropdownMenuItem<String>(
                 value: dropDownStringItem,
                 child: Text(dropDownStringItem),
                );
             }).toList(),
             onChanged: ( String novoItemSelecionado) {
               _dropDownItemSelected(novoItemSelecionado);
               setState(() {
                this._itemSelecionado =  novoItemSelecionado;
               });
             },
             value: _itemSelecionado,
           ),
           Text("O tipo selecionado foi \n$_itemSelecionado",
              style: TextStyle(fontSize: 20.0),
            ),
         ],
        ),
      );
   }
   void _dropDownItemSelected(String novoItem){
       setState(() {
        this._itemSelecionado = novoItem;
       });
   }
}