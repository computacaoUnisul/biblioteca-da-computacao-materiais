import 'package:flutter_web_aula/app_model.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_web_aula/domain/pagina.dart';


class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    AppModel app = Provider.of<AppModel>(context);
    Pagina pagina = app.pages.last;
    return pagina.pag;
  }
}
