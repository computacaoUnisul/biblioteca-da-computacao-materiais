package com.carros.carros.domain;

public class Imagem {

	
	private String fileName;
	private String mimeType;
	private String base64;
	
	public Imagem() {
		
	}
	public Imagem(String nomeArq, String mimeType, String base64) {
		this.fileName = nomeArq;
		this.mimeType = mimeType;
		this.base64 = base64;
	}

	public String getFilename() {
		return fileName;
	}

	public void setFilename(String fileName) {
		this.fileName = fileName;
	}

	public String getMimeType() {
		return mimeType;
	}

	public void setMymeType(String mimeType) {
		this.mimeType = mimeType;
	}

	public String getBase64() {
		return base64;
	}

	public void setBase64(String base64) {
		this.base64 = base64;
	}


	
}
