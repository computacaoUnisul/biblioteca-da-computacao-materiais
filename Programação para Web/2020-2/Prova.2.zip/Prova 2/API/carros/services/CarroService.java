package com.carros.carros.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carros.carros.domain.Carro;
import com.carros.carros.repositories.CarroRepository;

@Service
public class CarroService {
	
	@Autowired
	CarroRepository rep;
	
	public Carro salvar(Carro c) {
		return rep.save(c);
	}
	
	public boolean excluir(Integer id) {
		Optional<Carro> opt = rep.findById(id);
		if(opt.isPresent()) {
			rep.deleteById(id);
			return true;
		}
		return false;
	}
	
	public List<Carro> listaCarros(){
		return rep.findAll();
	}
	public List<Carro> buscaPorNome(String filtro){ 
		 return rep.findByNomeLike(filtro+"%"); 
		 
	 }
	/*
	 * public Carro editar(Carro c, Integer id) { Assert.notNull(id,
	 * "não foi possível atualizar o carro"); Optional<Carro> opt =
	 * rep.findById(id); if(opt.isPresent()) { Carro car = opt.get();
	 * car.setNome(c.getNome()); car.setAno(c.getAno()); rep.save(car); return car;
	 * }else {
	 * 
	 * return rep.save(c); } }
	 */
	
	
}
