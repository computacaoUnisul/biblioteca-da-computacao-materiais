package com.carros.carros.services;


import java.io.FileOutputStream;
import java.util.Base64;

import org.springframework.stereotype.Service;

import com.carros.carros.domain.Imagem;

@Service
public class ImagemService {
	
		
		public void uploadImagem(Imagem imagem) throws Exception {
	        byte[] imageBytes = Base64.getDecoder().decode(imagem.getBase64());
	        String directory = "imagens/"+imagem.getFilename();
	        new FileOutputStream(directory).write(imageBytes);
	   
		}
	

}
