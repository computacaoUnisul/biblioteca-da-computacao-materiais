package com.carros.carros.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.carros.carros.domain.Imagem;
import com.carros.carros.services.ImagemService;

@RestController
@RequestMapping("/")
public class ImagemController {

	@Autowired
	private ImagemService service;

	 @PostMapping public Object store(@RequestBody Imagem imagem){ try {
	 service.uploadImagem(imagem); return imagem; }catch(Exception e){ return
	 "erro"; } }
}
