package com.carros.carros.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carros.carros.domain.Carro;
import com.carros.carros.repositories.CarroRepository;

@Service
public class CarroService {
	
	@Autowired
	CarroRepository rep;
	
	public boolean excluirCarro(Integer id) {
		Optional<Carro> opt = rep.findById(id);
		if(opt.isPresent()) {
			rep.deleteById(id);
			return true;
		}
		return false;
	}
	
	public Carro salvarCarro(Carro c) {
		return rep.save(c);
	}
	
	public List<Carro> listaCarros(){
		return rep.findAll();
	}
}
