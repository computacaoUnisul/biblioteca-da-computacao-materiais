package com.carros.carros.services;

import java.io.FileOutputStream;
import java.util.Base64;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.carros.carros.domain.Imagem;

@Service
public class ImagemService {
	
		
		public void uploadImagem(Imagem imagem) throws Exception {
	        byte[] imageBytes = Base64.getDecoder().decode(imagem.getBase64());
	        String directory = "imagens/"+imagem.getFilename();
	        new FileOutputStream(directory).write(imageBytes);
	   
		}
	

}
