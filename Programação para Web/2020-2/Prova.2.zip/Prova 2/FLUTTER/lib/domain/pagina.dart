import 'package:flutter/material.dart';

class Pagina{
  String titulo;
  Widget pag;

  Pagina (this.titulo, this.pag);

  @override
  String toString() {
    return titulo;
  }
}