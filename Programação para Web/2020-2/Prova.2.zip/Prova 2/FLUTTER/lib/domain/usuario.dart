Usuario usuario = Usuario();

class Usuario{


  int id;
  String login;
  String nome;
  String email;
  String urlFoto;
  String token;
  List<String> roles;


  bool selected = false;


  Usuario({this.id, this.login, this.nome, this.email, this.urlFoto, this.token, this.roles});

  Usuario.fromMap(Map<String, dynamic> map){
    id = map["id"];
    login = map["login"];
    nome = map["nome"];
    email = map["email"];
    urlFoto = map["urlFoto"];
    token = map["token"];
    roles = map["roles"] != null? map['roles'].cast<String>():null;
  }

  bool isAdmin(){
    return roles != null && roles.contains("ROLE_ADMIN");
  }

  @override
  String toString(){
    return 'Usuario{login: $login, nome: $nome, token: $token}';
  }



}