import 'dart:async';
import 'package:flutter_web_aula/app_model.dart';
import 'package:provider/provider.dart';

import 'carro.dart';
import 'dart:html' as html;
import 'package:flutter/material.dart';
import 'package:flutter_web_aula/pages/carros/carros_api.dart';
import 'package:flutter_web_aula/pages/upload/upload_api.dart';
import 'package:flutter_web_aula/pages/upload/upload_helper.dart';
import 'package:flutter_web_aula/utils/alert.dart';
import 'package:flutter_web_aula/utils/api_response.dart';

class CadastroCarro extends StatefulWidget {
  @override
  _CadastroCarroState createState() => _CadastroCarroState();
}

class _CadastroCarroState extends State<CadastroCarro> {

  final _formKey = GlobalKey<FormState>();
  final _txtNome = TextEditingController();
  final _txtDesc = TextEditingController();
  final uploadHelper = UploadHelper();
  String url;
  bool exibeProgresso = false;
  StreamSubscription<EstadoDoUpload> subscription;
  String tipoCarro ="";
  var _tipos = ['Luxo','Esportivo','Clássico','ESCOLHA O TIPO'];
  var _itemSelecionado = 'ESCOLHA O TIPO';

  @override
  void initState(){
    super.initState();
    subscription = uploadHelper.stream.listen((EstadoDoUpload estado) {
      _setEstadoUpload(estado);
    });
  }

  String _validaTxt(String txt){
    if(txt.toString().isEmpty || txt.toString() == ''){
      return "Digite o valor do campo ";
    }
    return null;
  }

  String _validaDropDown(String txt){
    if(_itemSelecionado == 'ESCOLHA O TIPO'){
      return "Escolha um tipo";
    }
    return null;
  }

  void _setEstadoUpload(EstadoDoUpload estado){
    if(estado.iniciou){
      print("Upload iniciado..");
      setState(() {
        exibeProgresso = true;
      });
    }else{
      _upload(estado.fileUpload);
    }
  }

  void _upload(FileUpload arq) async {
    ApiResponse<String> response =
    await UploadApi.upload(arq.fileName, arq.mimeType, arq.base64);
    if(response.ok){
      String url = response.resultado;
      print(url);
      setState(() {
        this.url = url;
        this.exibeProgresso = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Container(
        padding: EdgeInsets.all(16),
        child: Form(
          key: this._formKey,
          child: ListView(
            children: [
              Divider(),
              _campoDeTexto("Nome", "Nome do carro", controller: _txtNome, validacao: _validaTxt),
              Divider(),
              _campoDeTexto("Descrição", "Descrição do carro", controller: _txtDesc, validacao: _validaTxt),
              SizedBox(height: 20),
              _criaDropDownButton(),
              Divider(),
              Center(
                child: Container(
                  color: Colors.grey[100],
                  child: ConstrainedBox(
                    constraints: BoxConstraints.tightFor(height: 400, width: 500),
                    child: Center(
                      child: _montaTela(),
                    ),
                  ),
                ),
              ),

              SizedBox(width: 30),
              Divider(),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _botao("Cancelar", _onClickCancelar),
                  SizedBox(width: 30),
                  _botao2("Cadastrar", _onClickCadastrar),
                  SizedBox(width: 30),
                  _botao2("Upload de Imagem", _OnClickUpload),
                  SizedBox(width: 30),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  _montaTela(){
    if(url == null || exibeProgresso){
      if(exibeProgresso){
        return CircularProgressIndicator();
      }else{
        return FlutterLogo(size: 50,);
      }
    }else{
      return InkWell(
        onTap: (){
          html.window.open(url, "site");
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.network(url),
          ],
        ),
      );
    }
  }

  _criaDropDownButton() {
    return Container(
      child: Column(
        children: <Widget>[
          DropdownButton<String>(
            items : _tipos.map((String dropDownStringItem) {
              return DropdownMenuItem<String>(
                value: dropDownStringItem,
                child: Text(dropDownStringItem),
              );
            }).toList(),
            onChanged: ( String novoItemSelecionado) {
              _dropDownItemSelected(novoItemSelecionado);
              setState(() {
                this._itemSelecionado =  novoItemSelecionado;
              });
            },
            value: _itemSelecionado,
          ),
        ],
      ),
    );
  }
  void _dropDownItemSelected(String novoItem){
    setState(() {
      this._itemSelecionado = novoItem;
    });
  }

  _botao(String _titulo, Function _evento){
    return Container(
      height: 50,
      width: 250,

      child: RaisedButton(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        onPressed: _evento,
        color: Colors.red,
        child: Text(
          _titulo,
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
          ),
        ),
      ),
    );
  }

  _botao2(String _titulo, Function _evento){
    return Container(
      height: 50,
      width: 250,

      child: RaisedButton(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        onPressed: _evento,
        color: Colors.yellowAccent,
        child: Text(
          _titulo,
          style: TextStyle(
            color: Colors.black,
            fontSize: 18,
          ),
        ),
      ),
    );
  }

  _onClickCancelar () {
    AppModel app = Provider.of<AppModel>(context, listen: false);
    app.removePage();
  /*  return ("Cancelou");*/
  }

  void _OnClickUpload(){
    uploadHelper.fazUpload();
  }

  _onClickCadastrar () async{
    //CRIA OBJETO CARRO
    var c = Carro();
    c.nome = _txtNome.text;
    c.tipo = _itemSelecionado;
    c.descricao = _txtDesc.text;
    c.urlFoto = url;

    if(!_formKey.currentState.validate()){
      return;
    }

    //CHAMA API
    ApiResponse response = await CarrosApi.save(context, c);
    if (response.ok){
      alert(context, "Carro salvo com sucesso", "Cadastro");
      AppModel app = Provider.of<AppModel>(context, listen: false);
      app.removePage();
    }
    print("${c.nome}, ${c.tipo}, ${c.descricao}");
  }

  _campoDeTexto(String label, String hint, {bool obscure = false, controller, validacao }){
    return TextFormField(
      controller: controller,
      validator: validacao,
      keyboardType: TextInputType.text,
      obscureText: obscure,
      style: TextStyle(color: Colors.black),
      decoration: InputDecoration(
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
          labelText: label,
          labelStyle: TextStyle(fontSize: 16.0, color: Colors.black),
          hintText: hint
      ),
    );
  }

}