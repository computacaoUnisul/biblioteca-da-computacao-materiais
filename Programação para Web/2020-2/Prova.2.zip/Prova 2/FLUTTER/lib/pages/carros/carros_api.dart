import 'dart:convert' as convert;
import 'package:flutter_web_aula/domain/usuario.dart';
import 'package:flutter_web_aula/utils/api_response.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_web_aula/pages/carros/carro.dart';

class CarrosApi{

  static Future<ApiResponse> save(context, Carro c) async{
    try{
      String url = "http://localhost:8080/carros";
      String json = c.toJson();

      Map<String, String> headers = {
        "Content-Type":"application/json",
        "Authorization":"Bearer ${usuario.token}"
      };

      var response = await http.post(url, body: json, headers: headers);
      if(response.statusCode == 200 || response.statusCode == 201){
        Map mapResponse = convert.json.decode(response.body);
        Carro carro = Carro.fromMap(mapResponse);
        print("Carro salvo: ${carro.id}");
        print(carro);
        return ApiResponse.ok();

      }
      Map mapResponse = convert.json.decode(response.body);
      return ApiResponse.error(msg: mapResponse["error"]);
    }catch(e){
      print(e);
      return ApiResponse.error(msg: "Não foi possível cadastrar o carro");
    }
  }

  static Future<List<Carro>> getCarros(context) async {
    String url = "http://localhost:8080/carros";
    Map <String, String> headers = {
      "Content-Type":"application/json",
      "Authorization":"Bearer ${usuario.token}"
    };
    final response = await http.get(url, headers: headers);
    String json = response.body;
    List list = convert.json.decode(json);
    List<Carro> carros = list.map<Carro>((map) => Carro.fromMap(map)).toList();
    print(carros);
    return carros;
  }
  static Future<bool> excluir (context, Carro c) async {
    String url = 'http://localhost:8080/carros/${c.id}';
    var response = await http.delete(url);
    if (response.statusCode == 200) {
      print("Carro excluído");
      return true;
    }
    return false;
  }
}