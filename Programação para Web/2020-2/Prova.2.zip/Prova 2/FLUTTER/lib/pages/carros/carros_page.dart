import 'package:flutter/material.dart';
import 'package:flutter_web_aula/app_model.dart';
import 'package:flutter_web_aula/domain/pagina.dart';
import 'package:flutter_web_aula/pages/carros/detalhe_carro_page.dart';
import 'package:flutter_web_aula/utils/tipo_carro.dart';
import 'package:flutter_web_aula/web/web_utils.dart';
import 'package:flutter_web_aula/pages/carros/carro.dart';
import 'package:flutter_web_aula/pages/carros/carros_api.dart';
import 'package:provider/provider.dart';
import 'cadastro_carro_page.dart';


class CarrosPage extends StatefulWidget {
  @override
  _CarrosPageState createState() => _CarrosPageState();
}

class _CarrosPageState extends State<CarrosPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder<List<Carro>>(
        future: CarrosApi.getCarros(context),
        builder: (BuildContext context, AsyncSnapshot r){
          if(!r.hasData){
            return Center(
              child: CircularProgressIndicator(),
            );
          }
          List<Carro> carros = r.data;
          return _retornaListaCarros(carros);
        }
      ),
        floatingActionButton: FloatingActionButton(
          onPressed: () => _onClickCadastrar(),
          tooltip: 'Cadastra',
          child: const Icon(Icons.add),
        ),
    );
  }

  _retornaListaCarros(List<Carro> carros){
    return GridView.builder(
      itemCount: carros.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 5,
        mainAxisSpacing: 20,
        crossAxisSpacing: 20,
        childAspectRatio: 1.0),
      itemBuilder: (context, index){
        return LayoutBuilder(
          builder: (context, constraints){
            double tamanhoFonte = tamanho(
              constraints.maxWidth*0.07,
              minimo: 8,
              maximo: Theme.of(context).textTheme.bodyText2.fontSize,
            );
            Carro c = carros[index];
            return InkWell(
              onTap: () => _onClickCarro(c),
              child: Card(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                  Image.network(
                    c.urlFoto??"http://www.livroandroid.com.br/livro/carros/esportivos/Renault_Megane_Trophy.png"
                  ),
                    Text(
                      c.nome ?? " ",
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: tamanhoFonte),
                    )
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
  _onClickCarro(Carro c){
   AppModel app = Provider.of<AppModel>(context, listen: false);
   app.setPage(Pagina(c.nome??"Detalhes", DetalheCarroPage(c)));
  }
  _onClickCadastrar(){
    AppModel app = Provider.of<AppModel>(context, listen: false);
    app.setPage(Pagina("Detalhes", CadastroCarro()));
  }
  _botao(String _titulo, Function _evento){
    return Container(
      height: 50,
      width: 250,

      child: RaisedButton(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        onPressed: _evento,
        color: Colors.yellowAccent,
        child: Text(
          _titulo,
          style: TextStyle(
            color: Colors.black,
            fontSize: 18,
          ),
        ),
      ),
    );
  }
}
