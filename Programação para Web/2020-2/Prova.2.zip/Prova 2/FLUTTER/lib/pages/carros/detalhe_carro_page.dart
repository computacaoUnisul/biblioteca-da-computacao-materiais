import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:flutter_web_aula/app_model.dart';
import 'package:flutter_web_aula/pages/carros/carro.dart';
import 'package:flutter_web_aula/pages/carros/carros_api.dart';
import 'package:flutter_web_aula/utils/alert.dart';
import 'package:provider/provider.dart';

class DetalheCarroPage extends StatefulWidget{
  Carro c;
  DetalheCarroPage(this.c);

  @override
  _DetalheCarroPageState createState() => _DetalheCarroPageState();
  }

  class _DetalheCarroPageState extends State<DetalheCarroPage>{

  @override
  Widget build(BuildContext context){
  return _body();
  }

  _body(){
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Image.network(
            widget.c.urlFoto??"http://www.livroandroid.com.br/livro/carros/esportivos/Renaut_Megane_Trophy.png",
            width: 400,
            fit: BoxFit.fitHeight,
          ),
          Text(
            widget.c.nome ?? " ",
            overflow: TextOverflow.ellipsis,
          ),
          Text(
            widget.c.descricao ?? " ",
            overflow: TextOverflow.ellipsis,
          ),
          Row(
            children: <Widget>[
              RaisedButton(
                child: Text("Voltar"),
                onPressed: _onClickVoltar,
              ),
              _botaoExcluir(widget.c),
            ],
          )
        ],
      ),
    );
  }

  _botaoExcluir(Carro carro2){
    return Container(
        height: 40,
        width: 100,
        child: RaisedButton(
          onPressed: () {
            _onClickExcluir(carro2);
          },
          color: Colors.amber,child: Text("Excluir"),
        ),
    );
  }

  void _onClickVoltar(){
    AppModel app = Provider.of<AppModel>(context, listen: false);
    app.removePage();
  }

  _onClickExcluir(Carro carro) async {
    await CarrosApi.excluir(context, carro);
    alert(context, "Carro excluído do sistema", "Exclusão");
    AppModel app = Provider.of<AppModel>(context, listen: false);
    app.removePage();
    setState(() {});
  }
}