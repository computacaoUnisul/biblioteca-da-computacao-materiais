import 'package:flutter/material.dart';
import 'package:flutter_web_aula/pages/login/login_form.dart';

class LoginPage extends StatefulWidget{
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>{
  @override
  Widget build(BuildContext context){
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: _layoutImagemFundo(),
    );
  }

  _layoutImagemFundo(){
    return Stack(
      fit: StackFit.expand,

      children: <Widget>[
        _image("https://s2.best-wallpaper.net/wallpaper/3840x2160/1812/Ferrari-F1-racing-car-retro-driver_3840x2160.jpg"),
        Center(
          child: Container(
            width: 360,
            height: 350,
            decoration: BoxDecoration(
              color: Color.fromARGB(255, 242, 244, 245),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                      color: Color.fromARGB(255, 252, 0, 0),
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10),
                          topRight: Radius.circular(10)
                      )
                  ),
                  height: 76,
                  child: Center(
                    child: Text(
                      "Concecionária Monza - Ferrari",
                      style: TextStyle(color: Colors.white, fontSize: 22),
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.all(16),
                  child: _form(),
                )
              ],
            ),
          ),
        )
      ],
    );
  }

  _form(){
    return LoginForm();
  }
  _image(String s){
    return Image.asset(
      "assets/images/background.jpg",
      fit: BoxFit.cover,
    );
  }
}