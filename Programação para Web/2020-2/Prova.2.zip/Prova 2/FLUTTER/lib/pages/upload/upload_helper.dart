import 'dart:async';
import 'dart:html';

class EstadoDoUpload{
  bool iniciou;
  FileUpload fileUpload;
  EstadoDoUpload({this.iniciou = false, this.fileUpload});
}

class FileUpload{
  String fileName;
  String mimeType;
  String base64;
  FileUpload(this.fileName, this.mimeType, this.base64);
}

class UploadHelper{
  final _controller = StreamController<EstadoDoUpload>();
  Stream<EstadoDoUpload> get stream => _controller.stream;

  fazUpload(){
  InputElement uploadInput = FileUploadInputElement();
  uploadInput.click();

  uploadInput.onChange.listen((e) {
    List<File> arquivos = uploadInput.files;
    if(arquivos.length>0){
      final arq = arquivos[0];
      print("arquivo: ${arq.name}");
      _controller.add(EstadoDoUpload(iniciou: true));
      final reader = new FileReader();
      reader.onLoadEnd.listen((e) {
        Object result = reader.result;
        String s = result;
        print("S: $s");
        String base64 = s.substring(s.indexOf(",")+1);
        String mimeType = s.substring(s.indexOf(":")+1, s.indexOf(";"));
        final fileUpload = FileUpload(arq.name, mimeType, base64);
        _controller.add(EstadoDoUpload(fileUpload: fileUpload));
      });
      reader.readAsDataUrl(arq);
    }
  });
  }
  dispose(){
    _controller.close();
  }
}