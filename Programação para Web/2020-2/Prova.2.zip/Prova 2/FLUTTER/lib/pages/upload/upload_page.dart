import 'dart:async';
import 'dart:html' as html;
import 'package:flutter/material.dart';
import 'package:flutter_web_aula/pages/upload/upload_api.dart';
import 'package:flutter_web_aula/pages/upload/upload_helper.dart';
import 'package:flutter_web_aula/utils/api_response.dart';

class UploadPage extends StatefulWidget{
  @override
  _UploadPageState createState() => _UploadPageState();
}

class _UploadPageState extends State<UploadPage>{
  String url;
  bool exibeProgresso = false;
  final uploadHelper = UploadHelper();
  StreamSubscription<EstadoDoUpload> subscription;

  @override
  void initState(){
    super.initState();
    subscription = uploadHelper.stream.listen((EstadoDoUpload estado) {
      _setEstadoUpload(estado);
    });
  }

  @override
  Widget build(BuildContext context){
    return Scaffold(
      body: _body(),
    );
  }

  _body(){
    return ListView(
      children: <Widget>[
        SizedBox(
          height: 20,
        ),
        Center(
          child: RaisedButton(
            child: Text("Upload"),
            onPressed: _OnClickUpload,
          ),
        ),
        SizedBox(
          height: 20,
        ),
        Center(

          child: Container(
            color: Colors.grey[100],
            child: ConstrainedBox(
              constraints: BoxConstraints.tightFor(height: 480, width: 640),
              child: Center(
                child: _montaTela(),
              ),
            ),
          ),
        ),
      ],

    );
  }
  void _OnClickUpload(){
    uploadHelper.fazUpload();
  }
  void _setEstadoUpload(EstadoDoUpload estado){
    if(estado.iniciou){
      print("Upload iniciado..");
      setState(() {
        exibeProgresso = true;
      });
    }else{
      _upload(estado.fileUpload);
    }
  }
  void _upload(FileUpload arq) async {
    ApiResponse<String> response =
        await UploadApi.upload(arq.fileName, arq.mimeType, arq.base64);
    if(response.ok){
      String url = response.resultado;
      print(url);
      setState(() {
        this.url = url;
        this.exibeProgresso = false;
      });
    }
  }

  _montaTela(){
    if(url == null || exibeProgresso){
      if(exibeProgresso){
        return CircularProgressIndicator();
      }else{
        return FlutterLogo(size: 50,);
      }
    }else{
      return InkWell(
        onTap: (){
          html.window.open(url, "site");
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.network(url),
            Text(url),
          ],
        ),
      );
    }
  }
}