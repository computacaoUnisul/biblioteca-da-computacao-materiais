class tipo_carro {
  final String nomeTipo;
  final String tipo;

  tipo_carro(this.nomeTipo, this.tipo);

  static List<tipo_carro> tipos() {
    return <tipo_carro>[
      tipo_carro('Luxo', 'luxo'),
      tipo_carro('Esportivo', 'esportivo'),
      tipo_carro('Clásico', 'classico'),
    ];
  }
}