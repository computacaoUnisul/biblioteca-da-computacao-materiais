import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter_web_aula/domain/pagina.dart';

import '../app_model.dart';

class BreadCrumb extends StatefulWidget{
  @override
  _BreadCrumbState createState() => _BreadCrumbState();
}

class _BreadCrumbState extends State<BreadCrumb>{
  @override
  Widget build(BuildContext context) {
    AppModel app = Provider.of<AppModel>(context);
    return ListView.builder(
    itemCount: app.pages.length,
      scrollDirection:  Axis.horizontal,
      itemBuilder: (context, index) {
        Pagina p = app.pages[index];
        return InkWell(
          onTap: () => _onClickPage(index),
          child: Row(
          children: <Widget>[
            ConstrainedBox(
              constraints: BoxConstraints.expand(width: 50),
              child: Icon(
                index == 0 ? FontAwesomeIcons.home: FontAwesomeIcons.chevronRight,
                  color: Color.fromRGBO(252, 0, 0, 1),
              ),
            ),
            Text(p.titulo, style: TextStyle(fontSize: 20, color:  Color.fromRGBO(252, 0, 0, 1)),)
          ],
          ),
        );
      });
  }

  _onClickPage(int index){
    AppModel app = Provider.of<AppModel>(context);
    if(index==0){
      app.desempilhaTodas();
    }else{
      app.desempilhaAte(index);
      
    }
  }
}