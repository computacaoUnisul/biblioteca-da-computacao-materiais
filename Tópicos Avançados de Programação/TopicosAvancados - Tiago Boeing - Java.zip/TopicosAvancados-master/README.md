# TopicosAvancados
Tópicos Avançados de Programação (Interface em Java)
Semestre: 2017/1
--
- UNISUL - UNIVERSIDADE DO SUL DE SANTA CATARINA
- Professor: Clávison Martinelli Zapelini
- Disciplina: Tópicos Avançados de Programação (Java)
- Aluno: Tiago Boeing
- Curso: Ciência da Computação

--
<i>Alguns pacotes podem conter erros, por se tratar de atividades é necessário repará-los.</i>

<h4>Nome do pacote java: TopicosAvancados</h4>


<h2>MODO DE USAR:</h2>
Arquivos .java class e demais, dentro da pasta /src

<h3>Netbeans</h3>
Vá no menu Novo projeto > atribua qualquer nome ao projeto (ex.: poo).<br>
Guarde o local no disco onde seu projeto foi criado, por padrão o caminho é: <br>
<b>Documentos\NetBeansProjects\poo</b><br>
<i>*Neste caso, <b>poo</b> é o nome do projeto que criei.</i><br>
<br><br>
Navegue para a pasta de <b>projetos do NetBeans</b> clone o repositório dentro dela. Será criada uma subpasta chamada poo/ que conterá todos os arquivos organizados por mais subpastas e seus scripts.<br>
*No eclipse o procedimento é semelhante, mudando apenas o diretório do projeto.
