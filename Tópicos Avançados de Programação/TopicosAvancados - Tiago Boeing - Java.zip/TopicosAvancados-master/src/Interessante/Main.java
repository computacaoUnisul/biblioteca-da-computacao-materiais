package Interessante;

public class Main {

		public static void main(String[] args) throws InterruptedException {
			while(true) {
				System.out.println("||||||||||||||   ||||||||||||||   ||||||||||||||   ||||||||||||||                     ||||||||||||||   ||||||||||||||");
				Thread.sleep(300L);
				System.out.println("||||||||||||||   ||||||||||||||   ||||||||||||||   ||||||||||||||                     ||||||||||||||   ||||||||||||||");
				Thread.sleep(300L);
				System.out.println("||||             ||||       |||   |||     ||||||   ||||      ||||                     |||              |||           ");
				Thread.sleep(300L);
				System.out.println("||||             ||||       |||   |||       ||||   ||||      ||||                     |||              |||           ");
				Thread.sleep(300L);
				System.out.println("||||||||||||||   ||||       |||   |||        |||   ||||      ||||                     ||||||||||||||   ||||||||||||||");
				Thread.sleep(300L);
				System.out.println("||||||||||||||   ||||       |||   |||        |||   ||||||||||||||   |||||||||||||||   ||||||||||||||   ||||||||||||||");
				Thread.sleep(300L);
				System.out.println("|||||            ||||       |||   |||       ||||   ||||      ||||                                |||   |||           ");
				Thread.sleep(300L);
				System.out.println("|||||            ||||       |||   |||     ||||||   ||||      ||||                                |||   |||           ");
				Thread.sleep(300L);
				System.out.println("|||||            ||||||||||||||   ||||||||||||||   ||||      ||||                     ||||||||||||||   ||||||||||||||");
				Thread.sleep(300L);
				System.out.println("|||||            ||||||||||||||   ||||||||||||||   ||||      ||||                     ||||||||||||||   ||||||||||||||");
				System.out.println();
				System.out.println();
				System.out.println();
				System.out.println();
			}
		}
	
}
