package Interessante;

public class Main2 {

		public static void main(String[] args) throws InterruptedException {
			while(true) {
				System.out.println("||||||||||||||||       ||||      ||||||||||||||           |||||||||||||||||");
				Thread.sleep(100L);
				System.out.println("||||       |||||       ||||      ||||      ||||           |||           |||");
				Thread.sleep(100L);
				System.out.println("||||       |||||       ||||      ||||      ||||           |||           |||");
				Thread.sleep(100L);
				System.out.println("||||       |||||       ||||      ||||      ||||           |||           |||");
				Thread.sleep(100L);
				System.out.println("||||       |||||       ||||      ||||      ||||           |||||||||||||||||");
				Thread.sleep(100L);
				System.out.println("||||       |||||       ||||      ||||||||||||||           |||||||||||||||||");
				Thread.sleep(100L);
				System.out.println("||||       |||||       ||||      ||||      ||||                         |||");
				Thread.sleep(100L);
				System.out.println("||||       |||||       ||||      ||||      ||||                         |||");
				Thread.sleep(100L);
				System.out.println("||||||||||||||||       ||||      ||||      ||||           |||||||||||||||||");
				Thread.sleep(100L);
				System.out.println();
				System.out.println();
				System.out.println();
				System.out.println();
			}
		}
	
}
